------------------------------- Temporary tables -------------------------------------
-- Create a local temporary table
CREATE TABLE #LocalTempEmployee (
    empid INT,
    empname NVARCHAR(100),
    department NVARCHAR(50)
);

-- Insert data into the local temporary table
INSERT INTO #LocalTempEmployee (empid, empname, department)
VALUES
(1, 'John Doe', 'IT'),
(2, 'Jane Smith', 'HR'),
(3, 'Michael Johnson', 'Finance');

-- Select data from the local temporary table
SELECT * FROM #LocalTempEmployee;

-- Create a global temporary table
CREATE TABLE ##GlobalTempEmployee (
    empid INT,
    empname NVARCHAR(100),
    department NVARCHAR(50)
);

-- Insert data into the global temporary table
INSERT INTO ##GlobalTempEmployee (empid, empname, department)
VALUES
(4, 'Alice Brown', 'Marketing'),
(5, 'Bob White', 'Sales'),
(6, 'Charlie Green', 'Support');

-- Select data from the global temporary table
SELECT * FROM ##GlobalTempEmployee;

-- Create a stored procedure that creates and uses a local temporary table
CREATE PROCEDURE dbo.Proc_CreateLocalTempTable
AS
BEGIN
    -- Create a local temporary table inside the stored procedure
    CREATE TABLE #ProcLocalTempEmployee (
        empid INT,
        empname NVARCHAR(100),
        department NVARCHAR(50)
    );

    -- Insert data into the local temporary table
    INSERT INTO #ProcLocalTempEmployee (empid, empname, department)
    VALUES
    (7, 'David Clark', 'IT'),
    (8, 'Eva Adams', 'HR'),
    (9, 'Frank Brown', 'Finance');

    -- Select data from the local temporary table
    SELECT * FROM #ProcLocalTempEmployee;
END;

-- Execute the stored procedure
EXEC dbo.Proc_CreateLocalTempTable;

-- Drop the temporary tables (optional as they will be dropped automatically when the session ends)
DROP TABLE #LocalTempEmployee;
DROP TABLE ##GlobalTempEmployee;

/*
Scope:
Local temporary tables (#TempTable) are scoped to the session or connection that 
created them.
Global temporary tables (##TempTable) are visible to all sessions and connections, 
but are dropped when the last session using them is closed.

Performance:
Temporary tables are stored in the tempdb database and can handle larger datasets
more efficiently than table variables.
They can participate in transactions and are affected by rollbacks.
Temporary tables can be indexed and can have constraints (such as primary keys and 
foreign keys).

Usage:
Temporary tables are suitable for larger datasets and more complex operations.
*/


------------------------------ Table Variables -------------------------------------------
DECLARE @TempEmployee TABLE (
    empid INT,
    empname NVARCHAR(100),
    department NVARCHAR(50)
);

INSERT INTO @TempEmployee (empid, empname, department)
VALUES (1, 'John Doe', 'IT'), (2, 'Jane Smith', 'HR');

SELECT * FROM @TempEmployee;

--Scope:
/*Table variables have a scope limited to the batch, stored procedure, or 
function where they are declared.
--They cannot be explicitly dropped as they are automatically cleaned up 
when they go out of scope.

--Performance:
Table variables are generally stored in memory, but they can spill to disk
if they become large.
They do not participate in transactions, meaning they are not affected by rollbacks.
Table variables are less likely to cause recompilation of stored procedures, 
which can be beneficial for performance in some scenarios.

--Usage:
Table variables are ideal for smaller datasets and simpler operations.*/

-------------------------------------- Views -----------------------------------------------
-- Create Employee table
CREATE TABLE Employee (
    empid INT PRIMARY KEY,
    empname NVARCHAR(100),
    mobile_number NVARCHAR(15),
    city NVARCHAR(50),
    age INT,
    marital_status NVARCHAR(20),
    score FLOAT,
    graduation_percentage FLOAT,
    email_address NVARCHAR(100),
    emp_code NVARCHAR(20),
    department NVARCHAR(50)
);

-- Insert data into Employee table
INSERT INTO Employee (empid, empname, mobile_number, city, age, marital_status, score, graduation_percentage, email_address, emp_code, department)
VALUES
(1, 'Shah Rukh Khan', '9876543210', 'Mumbai', 55, 'Married', 90.5, 85.0, 'srk@example.com', 'E001', 'IT'),
(6, 'Ranbir', '9876543210', 'Mumbai', 40, 'Married', 90.5, 85.0, 'ranbir@example.com', 'E010', 'IT'),
(2, 'Amitabh Bachchan', '8765432109', 'Mumbai', 78, 'Married', 88.7, 82.3, 'amitabh@example.com', 'E002', 'HR'),
(3, 'Aamir Khan', '7654321098', 'Mumbai', 57, 'Married', 92.1, 88.5, 'aamir@example.com', 'E003', 'Finance'),
(4, 'Salman Khan', '6543210987', 'Mumbai', 56, 'Single', 85.9, 80.7, 'salman@example.com', 'E004', 'Sales'),
(5, 'Akshay Kumar', '5432109876', 'Mumbai', 54, 'Married', 87.5, 84.2, 'akshay@example.com', 'E005', 'Marketing');

-- Create updatable view
CREATE VIEW v_EmployeeDetails 
AS
SELECT * FROM Employee;

sp_helptext v_EmployeeDetails;

select * from v_EmployeeDetails;

-- Update operation on updatable view
UPDATE v_EmployeeDetails
SET age = 35
WHERE empid = 1;

-- Create non-updatable view
CREATE VIEW v_EmployeeSummary AS
SELECT department, COUNT(*) AS total_employees, AVG(age) AS average_age
FROM Employee
GROUP BY department;

select * from v_EmployeeSummary;

-- Update operation on non-updatable view
UPDATE v_EmployeeSummary
SET average_age = 35
WHERE department = 'Marketing';



-- Attempt to update non-updatable view (this will fail)
UPDATE v_EmployeeSummary
SET average_age = 50
WHERE department = 'IT';

----------------------- Example -2 ---------------------------------------------------
-- Create Task table
CREATE TABLE Task (
    task_id INT PRIMARY KEY,
    empid INT,
    task_name NVARCHAR(100),
    due_date DATE,
    status NVARCHAR(20),
    FOREIGN KEY (empid) REFERENCES Employee(empid)
);

-- Insert data into Task table
INSERT INTO Task (task_id, empid, task_name, due_date, status)
VALUES
(1, 1, 'Complete Project Report', '2024-07-20', 'Pending'),
(2, 2, 'Prepare Presentation', '2024-07-18', 'Pending'),
(3, 3, 'Analyze Financial Data', '2024-07-19', 'Completed'),
(4, 4, 'Plan Marketing Strategy', '2024-07-25', 'Pending'),
(5, 5, 'Sales Data Review', '2024-07-22', 'Completed'),
(6, 6, 'Data Review', '2024-08-22', 'Completed');

-- Create view that joins Employee and Task tables
CREATE VIEW v_EmployeeTask AS
SELECT 
    e.empid,
    e.empname,
    e.department,
    t.task_id,
    t.task_name,
    t.due_date,
    t.status
FROM Employee e
JOIN Task t ON e.empid = t.empid;

SELECT 
    e.empid,
    e.empname,
    e.department,
    t.task_id,
    t.task_name,
    t.due_date,
    t.status
FROM Employee e
JOIN Task t ON e.empid = t.empid;

-- Update task status through the joined view
UPDATE v_EmployeeTask
SET status = 'In Review'
WHERE department = 'IT' and empid = 1;

-- Verify the update
SELECT * FROM v_EmployeeTask;

------------------------------------------------- Indexes --------------------------------

----------------------------------------- Clustered Index -------------------------------
CREATE CLUSTERED INDEX idx_empid ON Employee(empid);

CREATE CLUSTERED INDEX idx_empid ON Employee(score asc);

select * from  employee;

CREATE CLUSTERED INDEX idx_department_empid ON Employee(department, empid);

select * from  employee;


----------------------------------------- Non-Clustered Index ----------------------------
-- Create non-clustered index on empname
CREATE NONCLUSTERED INDEX idx_empname ON Employee(empname);

CREATE NONCLUSTERED INDEX idx_city ON Employee(city);


------------------------------------------ unique- clustered -----------------------------
CREATE UNIQUE CLUSTERED INDEX idx_unique_empid ON Employee(empid);

select * from employee;
------------------------------------------ unique- Non clustered -------------------------
CREATE UNIQUE NONCLUSTERED INDEX idx_unique_email ON Employee(email_address);
select * from employee;


-------------- verify ------------------------------------------
SELECT 
    name AS index_name, 
    type_desc AS index_type, 
    is_unique 
FROM sys.indexes 
WHERE object_id = OBJECT_ID('Employee');