-- Insert initial data into Employees
select * from employees


-- Error handling for insert with duplicate EmployeeID
BEGIN TRY
    BEGIN TRANSACTION;
    -- Attempt to insert a duplicate EmployeeID
    INSERT INTO Employees (EmployeeID, EmployeeName, DepartmentID, Salary) VALUES (1, 'Suresh Patel', 2, 65000);
    
    COMMIT TRANSACTION;
    PRINT 'Insert succeeded.';
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION;
    PRINT 'Error occurred during insert: ' + ERROR_MESSAGE();
END CATCH;

-- Verify the data
SELECT * FROM Employees;

-- Error handling for update with non-existent DepartmentID
BEGIN TRY
    BEGIN TRANSACTION;
    
    -- Attempt to update to a non-existent DepartmentID
    UPDATE Employees
    SET DepartmentID = 5
    WHERE EmployeeID = 2;
    
    COMMIT TRANSACTION;
    PRINT 'Update succeeded.';
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION;
    PRINT 'Error occurred during update: ' + ERROR_MESSAGE();
END CATCH;

-- Verify the data
SELECT * FROM Employees;

-- Add foreign key constraint
ALTER TABLE Employees
ADD CONSTRAINT FK_Employees_Departments
FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID);

-- Error handling for delete with foreign key violation
BEGIN TRY
    BEGIN TRANSACTION;
    
    -- Attempt to delete a department that is referenced by Employees
    DELETE FROM Departments
    WHERE DepartmentID = 1;
    
    COMMIT TRANSACTION;
    PRINT 'Delete succeeded.';
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION;
    PRINT 'Error occurred during delete: ' + ERROR_MESSAGE();
END CATCH;

-- Verify the data
SELECT * FROM Departments;
SELECT * FROM Employees;

---------------------------------------- NULL OPERATIONS ----------------------------------
-- Use ISNULL to replace NULL Salary with a default value
SELECT EmployeeID, EmployeeName, ISNULL(Salary, 0) AS Salary
FROM Employees;

-- Use ISNULL to replace NULL DepartmentID with a default value
SELECT EmployeeID, EmployeeName, ISNULL(DepartmentID, 0) AS DepartmentID
FROM Employees;

-- Use COALESCE to replace NULL Salary with a default value
SELECT EmployeeID, EmployeeName, COALESCE(Salary, 0) AS Salary
FROM Employees;

-- Use COALESCE to replace NULL DepartmentID with a default value
SELECT EmployeeID, EmployeeName, COALESCE(DepartmentID, 0) AS DepartmentID
FROM Employees;

-- Aggregate functions typically ignore NULLs, but we can handle them explicitly
-- Calculate the total salary, replacing NULLs with 0
SELECT SUM(ISNULL(Salary, 0)) AS TotalSalary
FROM Employees;

-- Calculate the average salary, considering NULLs as 0
SELECT AVG(ISNULL(Salary, 0)) AS AverageSalary
FROM Employees;

-- Count the number of employees, including those with NULL DepartmentID
SELECT COUNT(*) AS TotalEmployees
FROM Employees;

-- Count the number of employees with non-NULL DepartmentID
SELECT COUNT(DepartmentID) AS EmployeesWithDepartment
FROM Employees;

--------------------------------------- SYNONYMNS -------------------------------------------
-- Create a synonym for the Employees table
CREATE SYNONYM EmployeeSyn FOR dbo.Employees;

-- Select data from the synonym instead of the original table
SELECT EmployeeID, EmployeeName, DepartmentID, Salary
FROM EmployeeSyn;

----------------------------------------- SEQUENCE --------------------------------------------
-- Create a sequence
CREATE SEQUENCE EmployeeIDSeq
    START WITH 1
    INCREMENT BY 1;

-- Insert data into Employees table using the sequence
INSERT INTO Employees (EmployeeID, EmployeeName, DepartmentID, Salary)
VALUES (NEXT VALUE FOR EmployeeIDSeq, 'Sunil Gupta', 2, 60000),
       (NEXT VALUE FOR EmployeeIDSeq, 'Rina Singh', 3, 72000);
------------------------------------------------------------------------------------------------
------------------------------------- Handling Duplicate Records -------------------------------

-- Identify duplicate records
SELECT EmployeeName, DepartmentID, COUNT(*)
FROM Employees
GROUP BY EmployeeName, DepartmentID
HAVING COUNT(*) > 1;


-- Delete duplicate records
WITH CTE AS (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY EmployeeName, DepartmentID ORDER BY EmployeeID) AS row_num
    FROM Employees
)
DELETE FROM CTE
WHERE row_num > 1;

-- Verify the data
SELECT * FROM Employees;

-- Add a UNIQUE constraint to prevent duplicates
ALTER TABLE Employees
ADD CONSTRAINT UQ_EmployeeName_DepartmentID UNIQUE (EmployeeName, DepartmentID);
