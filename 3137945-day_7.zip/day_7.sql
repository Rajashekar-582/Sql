-- Create Employees table
CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    EmployeeName NVARCHAR(100),
    DepartmentID INT,
    Salary DECIMAL(10, 2)
);

-- Create Departments table
CREATE TABLE Departments (
    DepartmentID INT PRIMARY KEY,
    DepartmentName NVARCHAR(50)
);

-- Create EmployeeAudit table to log changes
CREATE TABLE EmployeeAudit (
    AuditID INT PRIMARY KEY IDENTITY(1,1),
    Operation NVARCHAR(10),
    EmployeeID INT,
    EmployeeName NVARCHAR(100),
    DepartmentID INT,
    Salary DECIMAL(10, 2),
    ChangeDate DATETIME DEFAULT GETDATE()
);

-- Insert initial data into Departments
INSERT INTO Departments (DepartmentID, DepartmentName) VALUES
(1, 'HR'),
(2, 'Finance'),
(3, 'IT'),
(4, 'Marketing');

-- AFTER INSERT trigger on Employees
CREATE TRIGGER trg_AfterInsert_Employees
ON Employees
AFTER INSERT
AS
BEGIN
    INSERT INTO EmployeeAudit (Operation, EmployeeID, 
	EmployeeName, DepartmentID, Salary)
    SELECT 'INSERT', EmployeeID, EmployeeName, 
	DepartmentID, Salary
    FROM inserted;
END;

-- Insert into Employees table and test AFTER INSERT trigger
INSERT INTO Employees 
(EmployeeID, EmployeeName, DepartmentID, Salary) 
VALUES (1, 'Rajesh', 1, 50000);

SELECT * FROM Employees;
SELECT * FROM EmployeeAudit;

-- AFTER UPDATE trigger on Employees
CREATE TRIGGER trg_AfterUpdate_Employees
ON Employees
AFTER UPDATE
AS
BEGIN
    INSERT INTO EmployeeAudit (Operation, EmployeeID, 
	EmployeeName, DepartmentID, Salary)
    SELECT 'UPDATE', EmployeeID, EmployeeName,
	DepartmentID, Salary
    FROM inserted;
END;

-- Update Employees table and test AFTER UPDATE trigger
UPDATE Employees
SET EmployeeName = 'Rajesh Verma', DepartmentID = 2, 
Salary = 60000
WHERE EmployeeID = 1;

SELECT * FROM Employees;
SELECT * FROM EmployeeAudit;

-- AFTER DELETE trigger on Employees
CREATE TRIGGER trg_AfterDelete_Employees
ON Employees
AFTER DELETE
AS
BEGIN
    INSERT INTO EmployeeAudit (Operation, EmployeeID, EmployeeName, DepartmentID, Salary)
    SELECT 'DELETE', EmployeeID, EmployeeName, DepartmentID, Salary
    FROM deleted;
END;

-- Delete from Employees table and test AFTER DELETE trigger
DELETE FROM Employees
WHERE EmployeeID = 1;

SELECT * FROM Employees;
SELECT * FROM EmployeeAudit;
------------------------------------------ Instead of triggers --------------------------------
-- INSTEAD OF INSERT trigger on Employees
CREATE TRIGGER trg_InsteadOfInsert_Employees
ON Employees
INSTEAD OF INSERT
AS
BEGIN
    DECLARE @EmployeeID INT, @EmployeeName NVARCHAR(100), @DepartmentID INT,
	@Salary DECIMAL(10, 2);
    SELECT @EmployeeID = EmployeeID, @EmployeeName = EmployeeName,
	@DepartmentID = DepartmentID, @Salary = Salary
    FROM inserted;
    -- Insert into Employees table
    INSERT INTO Employees (EmployeeID, EmployeeName, DepartmentID, Salary)
    VALUES (@EmployeeID, @EmployeeName, @DepartmentID, @Salary);
    -- Log the insertion into EmployeeAudit
    INSERT INTO EmployeeAudit (Operation, EmployeeID, EmployeeName, DepartmentID, Salary)
    VALUES ('INSERT', @EmployeeID, @EmployeeName, @DepartmentID, @Salary);
END;

-- Insert into Employees table and test INSTEAD OF INSERT trigger
INSERT INTO Employees (EmployeeID, EmployeeName, DepartmentID, Salary) VALUES (2, 'Anjali Sharma', 3, 70000);
SELECT * FROM Employees;
SELECT * FROM EmployeeAudit;

-- INSTEAD OF UPDATE trigger on Employees
CREATE TRIGGER trg_InsteadOfUpdate_Employees
ON Employees
INSTEAD OF UPDATE
AS
BEGIN
    DECLARE @EmployeeID INT, @EmployeeName NVARCHAR(100), @DepartmentID INT, @Salary DECIMAL(10, 2);

    SELECT @EmployeeID = EmployeeID, @EmployeeName = EmployeeName, @DepartmentID = DepartmentID, @Salary = Salary
    FROM inserted;

    -- Update Employees table
    UPDATE Employees
    SET EmployeeName = @EmployeeName, DepartmentID = @DepartmentID, Salary = @Salary
    WHERE EmployeeID = @EmployeeID;

    -- Log the update into EmployeeAudit
    INSERT INTO EmployeeAudit (Operation, EmployeeID, EmployeeName, DepartmentID, Salary)
    VALUES ('UPDATE', @EmployeeID, @EmployeeName, @DepartmentID, @Salary);
END;

-- Update Employees table and test INSTEAD OF UPDATE trigger
UPDATE Employees
SET EmployeeName = 'Anjali Mehta', DepartmentID = 4, Salary = 80000
WHERE EmployeeID = 2;
SELECT * FROM Employees;
SELECT * FROM EmployeeAudit;

-- INSTEAD OF DELETE trigger on Employees
CREATE TRIGGER trg_InsteadOfDelete_Employees
ON Employees
INSTEAD OF DELETE
AS
BEGIN
    DECLARE @EmployeeID INT, @EmployeeName NVARCHAR(100), @DepartmentID INT, @Salary DECIMAL(10, 2);

    SELECT @EmployeeID = EmployeeID, @EmployeeName = EmployeeName, @DepartmentID = DepartmentID, @Salary = Salary
    FROM deleted;

    -- Delete from Employees table
    DELETE FROM Employees
    WHERE EmployeeID = @EmployeeID;

    -- Log the deletion into EmployeeAudit
    INSERT INTO EmployeeAudit (Operation, EmployeeID, EmployeeName, DepartmentID, Salary)
    VALUES ('DELETE', @EmployeeID, @EmployeeName, @DepartmentID, @Salary);
END;

-- Delete from Employees table and test INSTEAD OF DELETE trigger
DELETE FROM Employees
WHERE EmployeeID = 2;
SELECT * FROM Employees;
SELECT * FROM EmployeeAudit;
-------------------------------------------------------------------------------------------------------------------------------

-- Create a View joining Employees and Departments
CREATE VIEW EmployeeDeptView AS
SELECT e.EmployeeID, e.EmployeeName, d.DepartmentName, 
e.Salary
FROM Employees e
JOIN Departments d ON e.DepartmentID = d.DepartmentID;

-- Select from the view to verify
SELECT * FROM EmployeeDeptView;

insert into EmployeeDeptView(EmployeeID, EmployeeName,
DepartmentName, Salary) values (4, 'Vijay', 'HR', 390000);

-- Attempt to update the view (This will throw an error)
-- Update EmployeeDeptView
UPDATE EmployeeDeptView
SET EmployeeName = 'Anjali Reddy', 
DepartmentName = 'Sales', 
Salary = 90000
WHERE EmployeeID = 1;







-- INSTEAD OF UPDATE trigger on EmployeeDeptView
CREATE TRIGGER trg_InsteadOfUpdate_EmployeeDeptView
ON EmployeeDeptView
INSTEAD OF UPDATE
AS
BEGIN
    DECLARE @EmployeeID INT, @EmployeeName NVARCHAR(100), 
	@DepartmentName NVARCHAR(50), @Salary DECIMAL(10, 2);

    DECLARE @DepartmentID INT;

    SELECT @EmployeeID = EmployeeID,
	@EmployeeName = EmployeeName, 
	@DepartmentName = DepartmentName, @Salary = Salary
    FROM inserted;

    SELECT @DepartmentID = DepartmentID FROM 
	Departments WHERE DepartmentName = @DepartmentName;
    -- Update Employees table
    UPDATE Employees
    SET EmployeeName = @EmployeeName, 
	DepartmentID = @DepartmentID, Salary = @Salary
    WHERE EmployeeID = @EmployeeID;
    -- Log the update into EmployeeAudit
    INSERT INTO EmployeeAudit 
	(Operation, EmployeeID, EmployeeName, DepartmentID, Salary)
    VALUES ('UPDATE', @EmployeeID, @EmployeeName, 
	@DepartmentID, @Salary);
END;

-- Insert into Employees table for further testing
INSERT INTO Employees (EmployeeID, EmployeeName, DepartmentID, Salary)
VALUES (3, 'Amit Gupta', 2, 55000);
SELECT * FROM Employees;
select * from Departments;
SELECT * FROM EmployeeAudit;

-- Update the view using INSTEAD OF UPDATE trigger
UPDATE EmployeeDeptView
SET EmployeeName = 'Rajesh Kumar', Salary = 58000
WHERE EmployeeID = 1;
SELECT * FROM EmployeeDeptView;
SELECT * FROM Employees;
SELECT * FROM EmployeeAudit;


-- Additional Delete for thorough testing
DELETE FROM Employees
WHERE EmployeeID = 3;
SELECT * FROM Employees;
SELECT * FROM EmployeeAudit;



Create tables:
. Sales table (Sale_id, product_id, product_name, quantity, 
total_sale_value)
. Stock details (product_id, product_name, stock_value, in_stock)
. product details (product_id, Product_name, price)
. Audit table: (audit_id, operation,complete_details) 

1. create triggers as a new sale happens. Update audit table with complete sale details
and also update the stock table.
2. create triggers to audit table with the details related to
the stock of the product gets updated from the stock details table.
3. create a trigger as we update the product details like price or name of the product to audit table
4. Create a view and write a trigger when inserted / updated / deleted a row from a view 
which has following details (sale_id, product_id, in_stock, and price)