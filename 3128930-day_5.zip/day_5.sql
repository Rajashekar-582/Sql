-- stored procedure with output parameter -------------------------------------------

CREATE TABLE dev_employees (
    emp_id INT PRIMARY KEY,
    emp_name VARCHAR(100),
    department_id INT,
    salary DECIMAL(10, 2)
);

INSERT INTO dev_employees (emp_id, emp_name, department_id, salary)
VALUES
(1, 'Sathish', 10, 50000.00),
(2, 'Anuraag', 20, 60000.00),
(3, 'Vijay', 10, 55000.00);

-- 1)
CREATE PROCEDURE GetAverageSalaryByDepartment
    @DepartmentID INT,
    @AverageSalary DECIMAL(10, 2) OUTPUT
AS
BEGIN
    SELECT @AverageSalary = AVG(salary)
    FROM dev_employees
    WHERE department_id = @DepartmentID;
END;


--- output ---------
DECLARE @AvgSalary DECIMAL(10, 2);

-- Execute the stored procedure
EXEC GetAverageSalaryByDepartment @DepartmentID = 10, @AverageSalary = @AvgSalary output;

-- Display the result
SELECT @AvgSalary AS AverageSalary;

------------------------------------ Functions --------------------------------------------

------------------ Built-In functions -----------------------------------------------------

-- Create the team_bleedblue table
CREATE TABLE team_bleedblue (
    player_id INT PRIMARY KEY,
    player_name VARCHAR(100),
    city VARCHAR(100),
    age INT,
    role VARCHAR(50),
    skills VARCHAR(100),
    coach VARCHAR(100),
    debut_date DATE,
    highest_scores INT,
    batting_average DECIMAL(5,2),
    DateofBirth DATE
);

-- Insert data into team_bleedblue
INSERT INTO team_bleedblue (player_id, player_name, city, age, role, skills, coach, debut_date, highest_scores, batting_average, DateofBirth) VALUES
(1, 'Virat Kohli', 'Delhi', 35, 'Batsman', 'Batting', 'Ravi Shastri', '2008-08-18', 183, 59.34, '1988-11-05'),
(2, 'Rohit Sharma', 'Mumbai', 37, 'Batsman', 'Batting', 'Rahul Dravid', '2007-06-23', 264, 48.96, '1987-04-30'),
(3, 'Shikhar Dhawan', 'Delhi', 38, 'Batsman', 'Batting', 'Ravi Shastri', '2010-10-20', 143, 44.15, '1985-12-05'),
(4, 'KL Rahul', 'Bangalore', 32, 'Wicketkeeper', 'Batting, Keeping', 'Rahul Dravid', '2014-12-26', 132, 46.96, '1992-04-18'),
(5, 'Hardik Pandya', 'Baroda', 30, 'All-rounder', 'Batting, Bowling', 'Vikram Solanki', '2016-01-26', 92, 34.25, '1993-10-11'),
(6, 'Rishabh Pant', 'Delhi', 26, 'Wicketkeeper', 'Batting, Keeping', 'Ravi Shastri', '2017-08-18', 159, 45.85, '1997-10-04'),
(7, 'Jasprit Bumrah', 'Ahmedabad', 30, 'Bowler', 'Bowling', 'Rahul Dravid', '2016-01-23', 55, 11.50, '1993-12-06'),
(8, 'Ravindra Jadeja', 'Rajkot', 35, 'All-rounder', 'Batting, Bowling', 'Vikram Solanki', '2009-02-08', 175, 32.75, '1988-12-06'),
(9, 'Yuzvendra Chahal', 'Jind', 33, 'Bowler', 'Bowling', 'Rahul Dravid', '2016-06-11', 6, 9.50, '1990-07-23'),
(10, 'Shreyas Iyer', 'Mumbai', 29, 'Batsman', 'Batting', 'Ravi Shastri', '2017-11-10', 103, 42.50, '1994-12-06'),
(11, 'Bhuvneshwar Kumar', 'Meerut', 34, 'Bowler', 'Bowling', 'Rahul Dravid', '2012-12-25', 53, 22.50, '1990-02-05');

-- Create the team_maroon_mavericks table
CREATE TABLE team_maroon_mavericks (
    player_id INT PRIMARY KEY,
    player_name VARCHAR(100),
    city VARCHAR(100),
    age INT,
    role VARCHAR(50),
    skills VARCHAR(100),
    coach VARCHAR(100),
    debut_date DATE,
    highest_scores INT,
    batting_average DECIMAL(5,2),
    DateofBirth DATE
);

-- Insert data into team_maroon_mavericks
INSERT INTO team_maroon_mavericks (player_id, player_name, city, age, role, skills, coach, debut_date, highest_scores, batting_average, DateofBirth) VALUES
(1, 'MS Dhoni', 'Ranchi', 42, 'Wicketkeeper', 'Batting, Keeping', 'Stephen Fleming', '2004-12-23', 183, 50.57, '1981-07-07'),
(2, 'Yuvraj Singh', 'Chandigarh', 42, 'All-rounder', 'Batting, Bowling', 'Anil Kumble', '2000-10-03', 150, 36.55, '1981-12-12'),
(3, 'Suresh Raina', 'Muradnagar', 37, 'Batsman', 'Batting', 'Stephen Fleming', '2005-07-30', 120, 35.30, '1986-11-27'),
(4, 'Ravichandran Ashwin', 'Chennai', 37, 'Bowler', 'Bowling, Batting', 'Anil Kumble', '2010-11-15', 124, 27.25, '1986-09-17'),
(5, 'Dinesh Karthik', 'Chennai', 39, 'Wicketkeeper', 'Batting, Keeping', 'Gary Kirsten', '2004-09-05', 94, 29.25, '1985-06-01'),
(6, 'Harbhajan Singh', 'Jalandhar', 43, 'Bowler', 'Bowling, Batting', 'Gary Kirsten', '1998-03-25', 79, 18.22, '1980-07-03'),
(7, 'Mohammed Shami', 'Amroha', 33, 'Bowler', 'Bowling', 'Bharat Arun', '2013-01-05', 51, 14.50, '1990-09-03'),
(8, 'Irfan Pathan', 'Baroda', 39, 'All-rounder', 'Batting, Bowling', 'Greg Chappell', '2003-12-15', 123, 23.65, '1984-10-27'),
(9, 'Zaheer Khan', 'Shirpur', 45, 'Bowler', 'Bowling', 'John Wright', '2000-10-03', 75, 15.25, '1978-10-07'),
(10, 'Virender Sehwag', 'Najafgarh', 44, 'Batsman', 'Batting', 'John Wright', '1999-04-01', 219, 49.34, '1978-10-20'),
(11, 'Rahul Dravid', 'Indore', 51, 'Batsman', 'Batting', 'John Wright', '1996-04-03', 270, 52.63, '1973-01-11');

-- Aggregate Functions

-- Count the number of players in team_bleedblue
SELECT COUNT(*) AS total_players
FROM team_bleedblue;

-- Calculate the average score of players in team_maroon_mavericks
SELECT AVG(highest_scores) AS average_highest_score
FROM team_maroon_mavericks;

SELECT SUM(highest_scores) AS total_highest_scores
FROM team_bleedblue;

SELECT MIN(batting_average) AS min_batting_average
FROM team_maroon_mavericks;


-- String Functions

-- Concatenate the player name and city for players in team_bleedblue
SELECT CONCAT(player_name, ' from ', city) AS player_location
FROM team_bleedblue;

-- Convert the player names in team_maroon_mavericks to uppercase
SELECT UPPER(player_name) AS upper_name
FROM team_maroon_mavericks;

-- Find the position of the first occurrence of 'a' in player names
SELECT player_name, PATINDEX('%a%', player_name) AS position_of_a
FROM team_bleedblue;

-- Replace 'a' with 'A' in player names
SELECT REPLACE(player_name, 'a', 'A') AS replaced_name
FROM team_maroon_mavericks;

-- Add spaces to the player names
SELECT player_name, SPACE(5) AS spaces, player_name
FROM team_bleedblue;

-- Insert a string into player names at a specified position
SELECT player_name, STUFF(player_name, 1, 0, 'Mr. ') AS new_name
FROM team_maroon_mavericks;

-- Repeat a character multiple times for each player
SELECT player_name, REPLICATE('M', 5) AS stars
FROM team_bleedblue;

-- Extract the first three characters from player names
SELECT player_name, LEFT(player_name, 3) AS first_three_chars
FROM team_maroon_mavericks;

-- Extract the last three characters from player names
SELECT player_name, RIGHT(player_name, 3) AS last_three_chars
FROM team_bleedblue;


-- Date and Time Functions

-- Get the current date and time
SELECT NOW() AS current_datetime;

-- Extract the year from the date of birth
SELECT player_name, YEAR(DateofBirth) AS birth_year
FROM team_bleedblue;

--Extract the day from the DateofBirth
SELECT player_name, DAY(DateofBirth) AS birth_day
FROM team_maroon_mavericks;

SELECT player_name, MONTH(debut_date) AS debut_month
FROM team_bleedblue;

-- Add 5 years to the debut date
SELECT player_name, DATEADD(YEAR, 5, debut_date) AS debut_plus_5_years
FROM team_maroon_mavericks;

-- Calculate the difference in years between debut date and DateofBirth
SELECT player_name, DATEDIFF(YEAR, DateofBirth, debut_date) AS years_between
FROM team_bleedblue;

-- Extract a specific part of the date (e.g., year) from the DateofBirth
SELECT player_name, DATEPART(YEAR, DateofBirth) AS birth_year
FROM team_bleedblue;


-- Mathematical Functions

-- Round the batting averages of players in team_maroon_mavericks
SELECT player_name, ROUND(batting_average, 1) AS rounded_average
FROM team

-- Get the ceiling value of batting averages in team_bleedblue
SELECT player_name, CEILING(batting_average) AS ceiling_batting_average
FROM team_bleedblue;

-- Get the floor value of batting averages in team_maroon_mavericks
SELECT player_name, FLOOR(batting_average) AS floor_batting_average
FROM team_maroon_mavericks;

-- Get the absolute value of the difference between highest_scores and batting_average
SELECT player_name, ABS(highest_scores - batting_average) AS abs_difference
FROM team_bleedblue;



------------------------------ User-Defined Functions -------------------------------------

------------------------------ Scalar Functions -------------------------------------------

-- Function to Calculate current Age from DateofBirth
CREATE FUNCTION dbo.CalculateAgeFromDOB1 (@dob DATE)
RETURNS INT
AS
BEGIN
    RETURN DATEDIFF(YEAR, @dob, GETDATE());
END;
GO

SELECT player_name, DateofBirth, dbo.CalculateAgeFromDOB1(DateofBirth) AS age
FROM team_bleedblue;


CREATE FUNCTION dbo.CalculateAgeFromDOB2 (@dob DATE)
RETURNS INT
AS
BEGIN
    RETURN DATEDIFF(YEAR, @dob, GETDATE()) - 
           CASE WHEN (MONTH(@dob) > MONTH(GETDATE())) 
                     OR (MONTH(@dob) = MONTH(GETDATE()) AND DAY(@dob) > DAY(GETDATE())) 
                THEN 1 
                ELSE 0 
           END;
END;
GO

SELECT player_name, DateofBirth, dbo.CalculateAgeFromDOB2(DateofBirth) AS age
FROM team_bleedblue;

-- Function to Calculate Batting Average
CREATE FUNCTION dbo.CalculateBattingAverage (@highest_scores INT, @matches_played INT)
RETURNS DECIMAL(5, 2)
AS
BEGIN
    DECLARE @batting_avg DECIMAL(5, 2);
    IF @matches_played > 0 
        SET @batting_avg = CAST(@highest_scores AS DECIMAL(5, 2)) / @matches_played;
    ELSE 
        SET @batting_avg = 0;
    RETURN @batting_avg;
END;
GO

SELECT player_name, highest_scores, dbo.CalculateBattingAverage(highest_scores, 50) AS calculated_avg
FROM team_bleedblue;

-----------------------------------------------------------------------------------------
------------------------------------- In-Lined Table Valued Function --------------------
-- 1) List Players with Experience Greater Than a Given Number of Years
CREATE FUNCTION dbo.PlayersWithExperience (@years INT)
RETURNS TABLE
AS
RETURN
(
    SELECT player_id, player_name, debut_date, DATEDIFF(YEAR, debut_date, GETDATE()) AS experience
    FROM team_bleedblue
    WHERE DATEDIFF(YEAR, debut_date, GETDATE()) > @years
);
GO

SELECT * FROM dbo.PlayersWithExperience(5);

-- 2) List Players by City
CREATE FUNCTION dbo.PlayersByCity (@city NVARCHAR(100))
RETURNS TABLE
AS
RETURN
(
    SELECT player_id, player_name, city, role
    FROM team_maroon_mavericks
    WHERE city = @city
);
GO

SELECT * FROM dbo.PlayersByCity('Hyderabad');

-- 3) Get player stats
CREATE FUNCTION dbo.PlayerStatistics (@player_id INT)
RETURNS TABLE
AS
RETURN
(
    SELECT player_id, player_name, highest_scores, batting_average
    FROM team_bleedblue
    WHERE player_id = @player_id
);
GO

-- Example usage: Get statistics for a player with ID 1 in team_bleedblue
SELECT * FROM dbo.PlayerStatistics(1);



------------------------------------------------------------------------------------------
---------------------------------- Multi-Statement Table-Valued Function------------------

-- 1) Function to List Players with Highest Scores Above a Threshold
CREATE FUNCTION dbo.PlayersWithHighScores (@threshold INT)
RETURNS @Result TABLE
(
    player_id INT,
    player_name NVARCHAR(100),
    highest_scores INT
)
AS
BEGIN
    INSERT INTO @Result
    SELECT 
        player_id,
        player_name,
        highest_scores
    FROM team_bleedblue
    WHERE highest_scores > @threshold;
    RETURN;
END;
GO

-- Example usage: Get players with highest scores above 100 in team_bleedblue
SELECT * FROM dbo.PlayersWithHighScores(100);













