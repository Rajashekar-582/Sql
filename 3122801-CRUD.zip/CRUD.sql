# creating a database
CREATE DATABASE employee_details;

USE employee_details;

# creating a table without primarykey
CREATE TABLE finance_team_details (
    employeeID int NOT NULL,
    FirstName varchar(50),
    LastName varchar(50),
    DateOfBirth date
);

# creating a table with primarykey
CREATE TABLE IT_team_details (
    employeeID int NOT NULL  ,
    FirstName varchar(50),
    LastName varchar(50),
    DateOfBirth date,
    PRIMARY KEY (employeeID)
);

# creating a table with composite primary key
CREATE TABLE tasks (
    employeeID int NOT NULL,
    taskID int NOT NULL,
    taskDate date,
    PRIMARY KEY (employeeID, taskID)
);

# inserting data into finance team details table where there is no primary key, and auto increment column.
INSERT INTO finance_team_details (employeeID, FirstName, LastName, DateOfBirth) VALUES 
(101, 'Vikram', 'Krishna', '1985-02-18'),
(102, 'Siddharth', 'Menon', '1987-07-12'),
(103, 'Priya', 'Bhatia', '1991-03-28'),
(104, 'Rohan', 'Chopra', '1990-06-15'),
(105, 'Neha', 'Malhotra', '1992-08-20'),
(106, 'Arjun', 'Iyengar', '1988-11-03'),
(107, 'Pooja', 'Deshmukh', '1993-01-19'),
(108, 'Rahul', 'Kapoor', '1989-09-05'),
(110, 'Sneha', 'Gupta', '1994-12-21'),
(109, 'Ajay', 'Pandey', '1991-04-10');

INSERT INTO IT_team_details (FirstName, LastName, DateOfBirth) VALUES 
('Aarav', 'Reddy', '1990-01-15'),
('Vivaan', 'Nair', '1988-05-20'),
('Aditya', 'Sharma', '1992-12-11'),
('Sai', 'Kumar', '1991-03-05'),
('Nikhil', 'Verma', '1993-07-09'),
('Ananya', 'Singh', '1994-04-23'),
('Kavya', 'Patel', '1995-06-17'),
('Ishaan', 'Das', '1990-10-30'),
('Riya', 'Joshi', '1992-09-12'),
('Mira', 'Rao', '1989-11-25');

INSERT INTO tasks (employeeID, taskID, taskDate) VALUES 
(1, 101, '2024-01-10'),
(2, 102, '2024-01-12'),
(3, 103, '2024-01-15'),
(4, 104, '2024-01-18'),
(5, 105, '2024-01-20'),
(6, 106, '2024-01-22'),
(7, 107, '2024-01-25'),
(8, 108, '2024-01-27'),
(9, 109, '2024-01-30'),
(10, 110, '2024-02-02'),
(11, 111, '2024-02-05'),
(12, 112, '2024-02-07'),
(13, 113, '2024-02-10'),
(14, 114, '2024-02-12'),
(15, 115, '2024-02-15'),
(16, 116, '2024-02-18'),
(17, 117, '2024-02-20'),
(18, 118, '2024-02-22'),
(19, 119, '2024-02-25'),
(20, 120, '2024-02-28');


# Altering tables
ALTER TABLE finance_team_details
ADD qualification varchar(50),
ADD graduation_college varchar(100),
ADD graduation_year int,
ADD cityname varchar(50),
ADD statename varchar(50),
ADD country varchar(50);

ALTER TABLE IT_team_details
ADD qualification varchar(50),
ADD graduation_college varchar(100),
ADD graduation_year int,
ADD cityname varchar(50),
ADD statename varchar(50),
ADD country varchar(50);

ALTER TABLE tasks
ADD task_category varchar(50);

# inserting values to the altered tables
INSERT INTO finance_team_details (employeeID, FirstName, LastName, DateOfBirth, qualification, graduation_college, graduation_year, cityname, statename, country) VALUES 
(101, 'Vikram', 'Krishna', '1985-02-18', 'MBA', 'ABC University', 2008, 'Mumbai', 'Maharashtra', 'India'),
(102, 'Siddharth', 'Menon', '1987-07-12', 'B.Com', 'XYZ College', 2010, 'Bangalore', 'Karnataka', 'India'),
(103, 'Priya', 'Bhatia', '1991-03-28', 'B.Tech', 'DEF Institute of Technology', 2013, 'Delhi', 'Delhi', 'India'),
(104, 'Rohan', 'Chopra', '1990-06-15', 'M.Sc', 'GHI University', 2012, 'Chandigarh', 'Punjab', 'India'),
(105, 'Neha', 'Malhotra', '1992-08-20', 'Ph.D', 'JKL College', 2015, 'Pune', 'Maharashtra', 'India'),
(106, 'Arjun', 'Iyengar', '1988-11-03', 'MBA', 'MNO University', 2009, 'Chennai', 'Tamil Nadu', 'India'),
(107, 'Pooja', 'Deshmukh', '1993-01-19', 'B.Tech', 'PQR Institute of Technology', 2014, 'Hyderabad', 'Telangana', 'India'),
(108, 'Rahul', 'Kapoor', '1989-09-05', 'B.Com', 'STU College', 2011, 'Kolkata', 'West Bengal', 'India'),
(110, 'Sneha', 'Gupta', '1994-12-21', 'M.Sc', 'VWX University', 2016, 'Ahmedabad', 'Gujarat', 'India'),
(109, 'Ajay', 'Pandey', '1991-04-10', 'MBA', 'YZA University', 2013, 'Jaipur', 'Rajasthan', 'India');


INSERT INTO IT_team_details (FirstName, LastName, DateOfBirth, qualification, graduation_college, graduation_year, cityname, statename, country) VALUES 
('Aarav', 'Reddy', '1990-01-15', 'B.Tech', 'DEF Institute of Technology', 2012, 'Bangalore', 'Karnataka', 'India'),
('Vivaan', 'Nair', '1988-05-20', 'MCA', 'GHI University', 2011, 'Chennai', 'Tamil Nadu', 'India'),
('Aditya', 'Sharma', '1992-12-11', 'B.E', 'JKL College', 2015, 'Pune', 'Maharashtra', 'India'),
('Sai', 'Kumar', '1991-03-05', 'M.Sc', 'MNO University', 2013, 'Hyderabad', 'Telangana', 'India'),
('Nikhil', 'Verma', '1993-07-09', 'B.Tech', 'PQR Institute of Technology', 2016, 'Ahmedabad', 'Gujarat', 'India'),
('Ananya', 'Singh', '1994-04-23', 'B.Com', 'STU College', 2014, 'Kolkata', 'West Bengal', 'India'),
('Kavya', 'Patel', '1995-06-17', 'MBA', 'VWX University', 2017, 'Jaipur', 'Rajasthan', 'India'),
('Ishaan', 'Das', '1990-10-30', 'B.Sc', 'YZA University', 2012, 'Mumbai', 'Maharashtra', 'India'),
('Riya', 'Joshi', '1992-09-12', 'MCA', 'ABC University', 2014, 'Delhi', 'Delhi', 'India'),
('Mira', 'Rao', '1989-11-25', 'Ph.D', 'XYZ College', 2018, 'Chandigarh', 'Punjab', 'India');

INSERT INTO tasks (employeeID, taskID, taskDate, task_category) VALUES 
(11, 101, '2024-01-10', 'Database Management'),
(12, 102, '2024-01-12', 'Backend Development'),
(13, 103, '2024-01-15', 'Frontend Development'),
(14, 104, '2024-01-18', 'UI/UX Design'),
(15, 105, '2024-01-20', 'Quality Assurance'),
(16, 106, '2024-01-22', 'Project Management'),
(17, 107, '2024-01-25', 'Database Management'),
(18, 108, '2024-01-27', 'Backend Development'),
(19, 109, '2024-01-30', 'Frontend Development'),
(20, 110, '2024-02-02', 'UI/UX Design'),
(21, 111, '2024-02-05', 'Quality Assurance'),
(22, 112, '2024-02-07', 'Project Management'),
(23, 113, '2024-02-10', 'Database Management'),
(24, 114, '2024-02-12', 'Backend Development'),
(25, 115, '2024-02-15', 'Frontend Development'),
(26, 116, '2024-02-18', 'UI/UX Design'),
(27, 117, '2024-02-20', 'Quality Assurance'),
(28, 118, '2024-02-22', 'Project Management'),
(29, 119, '2024-02-25', 'Database Management'),
(30, 120, '2024-02-28', 'Backend Development');

#drop database employee_details;
#drop table tablename;






