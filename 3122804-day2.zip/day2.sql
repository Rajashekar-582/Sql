create database employee_track;

use employee_track;


CREATE TABLE emp_personal_data (
    empid SMALLINT NOT NULL IDENTITY(1,1),
    empname VARCHAR(100) NOT NULL,
    mobile_number VARCHAR(15) NOT NULL,
    city VARCHAR(50) NOT NULL,
    age INT NOT NULL,
    marital_status VARCHAR(2) NOT NULL,
    marks INT,
    graduation_percentage INT,
    email_address VARCHAR(100),
    emp_code VARCHAR(20) NOT NULL,
    department VARCHAR(50),
    PRIMARY KEY (empid)
);


-- Altering the table 

/*add a new column (employee's email address.)*/
ALTER TABLE emp_personal_data
ADD date_of_joining DATE;

/* Modifying the Data Type of a Column*/
ALTER TABLE emp_personal_data
ALTER COLUMN mobile_number CHAR(10) NOT NULL;

/*Renaming a Column*/
EXEC sp_rename 'emp_personal_data.marks', 'score', 'COLUMN';

/* dropping a column */
ALTER TABLE emp_personal_data
DROP COLUMN marital_status;

-- get all the details of table
EXEC sp_help 'emp_personal_data';

-- updating a column values based on a condition
UPDATE emp_personal_data
SET city = 'hyderabad'
WHERE empid IN (6, 7, 8, 9, 10);

-- adding a default value to a column
ALTER TABLE emp_personal_data
ADD CONSTRAINT F_emp_personal_data_email_address_domain
DEFAULT '@gmail.com' FOR email_address;

-- Adding a Unique Constraint (If we want to ensure that the email_address is unique for each employee)
ALTER TABLE emp_personal_data
ADD CONSTRAINT UQ_emp_personal_data_email_address 
UNIQ UE(email_address);

-- adding a check constraint
ALTER TABLE emp_personal_data
ADD CONSTRAINT CK_emp_personal_data_graduation_percentage
CHECK (graduation_percentage BETWEEN 0 AND 100);

-- inserting data
USE employee_track;

INSERT INTO emp_personal_data (empname, mobile_number, city, age, marital_status, score, graduation_percentage, email_address, emp_code, department, date_of_joining)
VALUES
('John Doe', '9876543210', 'Delhi', 28, 'M', 85, 75, 'john.doe@example.com', 'E001', 'HR', '2024-05-06'),
('Jane Smith', '9123456780', 'Mumbai', 25, 'S', 90, 80, 'jane.smith@example.com', 'E002', 'Finance', '2023-06-06'),
('Michael Johnson', '9876543211', 'Chennai', 30, 'M', 88, 78, 'michael.johnson@example.com', 'E003', 'Engineering', '2022-01-03'),
('Sunita Rao', '9876543212', 'Bangalore', 26, 'S', 92, 82, 'sunita.rao@example.com', 'E004', 'Marketing', '2024-05-06'),
('Amitabh Bachchan', '9876543213', 'Kolkata', 40, 'M', 95, 85, 'amitabh.bachchan@example.com', 'E005', 'Operations', '2024-05-06'),
('Kareena Kapoor', '9876543214', 'Pune', 27, 'S', 89, 79, 'kareena.kapoor@example.com', 'E006', 'IT', '2024-05-06'),
('Ravi Teja', '9876543215', 'Hyderabad', 32, 'M', 91, 81, 'ravi.teja@example.com', 'E007', 'Support', '2014-05-06'),
('Deepika Padukone', '9876543216', 'Delhi', 29, 'S', 87, 77, 'deepika.padukone@example.com', 'E008', 'Sales', '2012-05-06'),
('Sachin Tendulkar', '9876543217', 'Mumbai', 45, 'M', 93, 83, 'sachin.tendulkar@example.com', 'E009', 'Logistics', '2016-05-06'),
('Alia Bhatt', '9876543218', 'Kolkata', 24, 'S', 90, 80, 'alia.bhatt@example.com', 'E010', 'Admin', '2019-05-06');


-- Data retrieval

select * from emp_personal_data;

SELECT * FROM emp_personal_data
WHERE city = 'Delhi';

SELECT * FROM emp_personal_data
WHERE marital_status = 'S';

 

SELECT * FROM emp_personal_data
WHERE age BETWEEN 25 AND 30;

SELECT * FROM emp_personal_data
WHERE city IN ('Mumbai', 'Kolkata');

SELECT * FROM emp_personal_data
WHERE empname LIKE 'A%';

SELECT * FROM emp_personal_data
WHERE empname LIKE '%Kapoor%';

SELECT * FROM emp_personal_data
WHERE mobile_number LIKE '98%';

-- using orderby
SELECT * FROM emp_personal_data
WHERE city = 'Delhi'
ORDER BY age;

SELECT * FROM emp_personal_data
WHERE marital_status = 'S'
ORDER BY graduation_percentage DESC;

SELECT * FROM emp_personal_data
WHERE age BETWEEN 25 AND 30
ORDER BY empname;

SELECT * FROM emp_personal_data
WHERE city IN ('Mumbai', 'Kolkata')
ORDER BY city, empname;

--using groupby and count

select * from emp_personal_data;

select city, count(*) as count_of_emp from emp_personal_data group by city;

select  city, max(score) as avg_points_per_city from emp_personal_data group by city order by avg_points_per_city desc ;

-- 




SELECT city, count(*) AS employee_count
FROM emp_personal_data
GROUP BY city;

SELECT marital_status, AVG(graduation_percentage) AS avg_graduation_percentage
FROM emp_personal_data
GROUP BY marital_status;

SELECT department, MAX(score) AS max_score
FROM emp_personal_data
GROUP BY department;

SELECT city, MIN(age) AS min_age
FROM emp_personal_data
GROUP BY city;


--Combining ORDER BY and GROUP BY
SELECT city, COUNT(*) AS employee_count
FROM emp_personal_data
GROUP BY city
ORDER BY employee_count DESC;

SELECT department, AVG(score) AS avg_score
FROM emp_personal_data
WHERE age > 25
GROUP BY department
ORDER BY avg_score;

SELECT department, SUM(score) AS total_score
FROM emp_personal_data
WHERE graduation_percentage BETWEEN 70 AND 90
GROUP BY department
ORDER BY total_score DESC;

-- dealing with date columns
SELECT * FROM emp_personal_data
WHERE date_of_joining > '2024-01-01';

SELECT empname, date_of_joining
FROM emp_personal_data
WHERE date_of_joining > '2023-06-01';

SELECT * FROM emp_personal_data
WHERE date_of_joining BETWEEN '2019-01-01' AND '2020-12-31';

SELECT * FROM emp_personal_data
WHERE month(date_of_joining) = 2022;

SELECT empname, date_of_joining
FROM emp_personal_data
WHERE YEAR(date_of_joining) = 2023
AND MONTH(date_of_joining) = 5;

SELECT * FROM emp_personal_data
WHERE YEAR(date_of_joining) = YEAR(GETDATE());


--Retrieve the count of employees who joined in each year
SELECT YEAR(date_of_joining) AS join_year, COUNT(*) AS num_employees FROM emp_personal_data
GROUP BY YEAR(date_of_joining) order by num_employees desc;

--Retrieve the average age of employees based on their joining year
SELECT YEAR(date_of_joining) AS join_year, AVG(age) AS avg_age
FROM emp_personal_data
GROUP BY YEAR(date_of_joining)
ORDER BY join_year; 






















