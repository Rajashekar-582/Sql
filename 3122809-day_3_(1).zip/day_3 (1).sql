CREATE TABLE team_bleedblue (
    player_id INT PRIMARY KEY,
    player_name VARCHAR(100),
    city VARCHAR(50),
    age INT,
    role VARCHAR(50),
    skills VARCHAR(200),
    coach VARCHAR(100),
    debut_date DATE,
    highest_scores INT
);

INSERT INTO team_bleedblue (player_id, player_name, city, age, role, skills, coach, debut_date, highest_scores)
VALUES 
(1, 'Virat Kohli', 'Delhi', 34, 'Batsman', 'Batting, Fielding', 'Ravi Shastri', '2015-01-01', 183),
(2, 'Rohit Sharma', 'Mumbai', 36, 'Batsman', 'Batting, Fielding', 'Ravi Shastri', '2016-02-01', 264),
(3, 'MS Dhoni', 'Ranchi', 42, 'Wicketkeeper', 'Batting, Keeping', 'Ravi Shastri', '2014-03-01', 183),
(4, 'Jasprit Bumrah', 'Ahmedabad', 29, 'Bowler', 'Bowling, Fielding', 'Ravi Shastri', '2017-04-01', 20),
(5, 'Hardik Pandya', 'Surat', 30, 'Allrounder', 'Batting, Bowling', 'Ravi Shastri', '2018-05-01', 92),
(6, 'KL Rahul', 'Bangalore', 32, 'Batsman', 'Batting, Fielding', 'Ravi Shastri', '2019-06-01', 112),
(7, 'Rishabh Pant', 'Delhi', 26, 'Wicketkeeper', 'Batting, Keeping', 'Ravi Shastri', '2020-07-01', 128),
(8, 'Shikhar Dhawan', 'Delhi', 38, 'Batsman', 'Batting, Fielding', 'Ravi Shastri', '2013-08-01', 143),
(9, 'Ravindra Jadeja', 'Jamnagar', 34, 'Allrounder', 'Batting, Bowling', 'Ravi Shastri', '2011-09-01', 87),
(10, 'Yuzvendra Chahal', 'Jind', 33, 'Bowler', 'Bowling, Fielding', 'Ravi Shastri', '2012-10-01', 25);

CREATE TABLE team_maroon_mavericks (
    player_id INT PRIMARY KEY,
    player_name VARCHAR(100),
    city VARCHAR(50),
    age INT,
    role VARCHAR(50),
    skills VARCHAR(200),
    coach VARCHAR(100),
    debut_date DATE,
    highest_scores INT
);

INSERT INTO team_maroon_mavericks (player_id, player_name, city, age, role, skills, coach, debut_date, highest_scores)
VALUES 
(11, 'Sachin Tendulkar', 'Mumbai', 50, 'Batsman', 'Batting, Fielding', 'Anil Kumble', '2000-01-01', 200),
(12, 'Sourav Ganguly', 'Kolkata', 51, 'Batsman', 'Batting, Fielding', 'Anil Kumble', '2001-02-01', 183),
(13, 'Rahul Dravid', 'Bangalore', 51, 'Batsman', 'Batting, Fielding', 'Anil Kumble', '2002-03-01', 180),
(14, 'VVS Laxman', 'Hyderabad', 49, 'Batsman', 'Batting, Fielding', 'Anil Kumble', '2003-04-01', 281),
(15, 'Anil Kumble', 'Bangalore', 53, 'Bowler', 'Bowling, Fielding', 'Anil Kumble', '2004-05-01', 10),
(16, 'Harbhajan Singh', 'Jalandhar', 44, 'Bowler', 'Bowling, Fielding', 'Anil Kumble', '2005-06-01', 20),
(17, 'Zaheer Khan', 'Mumbai', 45, 'Bowler', 'Bowling, Fielding', 'Anil Kumble', '2006-07-01', 12),
(18, 'Virender Sehwag', 'Delhi', 45, 'Batsman', 'Batting, Fielding', 'Anil Kumble', '2007-08-01', 219),
(19, 'Gautam Gambhir', 'Delhi', 41, 'Batsman', 'Batting, Fielding', 'Anil Kumble', '2008-09-01', 150),
(10, 'Yuzvendra Chahal', 'Jind', 33, 'Bowler', 'Bowling, Fielding', 'Ravi Shastri', '2012-10-01', 25),
(1, 'Virat Kohli', 'Delhi', 34, 'Batsman', 'Batting, Fielding', 'Ravi Shastri', '2015-01-01', 183),
(2, 'Rohit Sharma', 'Mumbai', 36, 'Batsman', 'Batting, Fielding', 'Ravi Shastri', '2016-02-01', 264),
(3, 'MS Dhoni', 'Ranchi', 42, 'Wicketkeeper', 'Batting, Keeping', 'Ravi Shastri', '2014-03-01', 183);

-- Set operators

-- 1) Union
SELECT player_name, city, role FROM team_bleedblue
UNION
SELECT player_name, city, role FROM team_maroon_mavericks;

-- 2) Intersect
SELECT player_name FROM team_bleedblue
INTERSECT
SELECT player_name FROM team_maroon_mavericks;

-- 3) Except
SELECT player_name FROM team_bleedblue
EXCEPT
SELECT player_name FROM team_maroon_mavericks;

-- Joins

-- Inner Join
SELECT b.*, m.*
FROM team_bleedblue b
INNER JOIN team_maroon_mavericks m ON b.player_id = m.player_id;

-- Left Join
SELECT b.*, m.*
FROM team_bleedblue b
LEFT JOIN team_maroon_mavericks m ON b.player_id = m.player_id;

-- Right Join
SELECT b.*, m.*
FROM team_bleedblue b
RIGHT JOIN team_maroon_mavericks m ON b.player_id = m.player_id;

-- Full Outer Join
SELECT b.*, m.*
FROM team_bleedblue b
FULL OUTER JOIN team_maroon_mavericks m ON b.player_id = m.player_id;

-- Subqueries (Rank Functions)

-- Find the highest score and the corresponding player name from both teams
SELECT player_name, highest_scores
FROM team_bleedblue
WHERE highest_scores = (SELECT MAX(highest_scores) FROM team_bleedblue)
UNION
SELECT player_name, highest_scores
FROM team_maroon_mavericks
WHERE highest_scores = (SELECT MAX(highest_scores) FROM team_maroon_mavericks);


-- Alter table to add new column
ALTER TABLE team_bleedblue
ADD batting_average DECIMAL(5, 2);

ALTER TABLE team_maroon_mavericks
ADD batting_average DECIMAL(5, 2);

-- Update batting_average column for team_bleedblue
UPDATE team_bleedblue
SET batting_average = 
    CASE player_id
        WHEN 1 THEN 59.33
        WHEN 2 THEN 48.96
        WHEN 3 THEN 50.57
        WHEN 4 THEN 12.50
        WHEN 5 THEN 29.65
        WHEN 6 THEN 44.71
        WHEN 7 THEN 34.81
        WHEN 8 THEN 45.21
        WHEN 9 THEN 32.45
        WHEN 10 THEN 10.00
    END;

select * from team_bleedblue;

-- Update batting_average column for team_maroon_mavericks
UPDATE team_maroon_mavericks
SET batting_average = 
    CASE player_id
        WHEN 11 THEN 54.17
        WHEN 12 THEN 40.95
        WHEN 13 THEN 52.31
        WHEN 14 THEN 45.97
        WHEN 15 THEN 15.00
        WHEN 16 THEN 18.50
        WHEN 17 THEN 12.75
        WHEN 18 THEN 49.34
        WHEN 19 THEN 39.68
        WHEN 20 THEN 10.00
		WHEN 1 THEN 59.33
        WHEN 2 THEN 48.96
        WHEN 3 THEN 50.57
        WHEN 10 THEN 10.00
    END;

SELECT * FROM team_maroon_mavericks;

-- 1. Find the player with the highest batting average from both teams
SELECT player_name, batting_average
FROM (
    SELECT player_name, batting_average
    FROM team_bleedblue
    UNION ALL
    SELECT player_name, batting_average
    FROM team_maroon_mavericks
) AS all_players
WHERE batting_average = (SELECT MAX(batting_average) FROM (
                            SELECT batting_average FROM team_bleedblue
                            UNION ALL
                            SELECT batting_average FROM team_maroon_mavericks
                         ) AS all_batting_averages);

-- 2. Rank players based on their highest scores within each team
SELECT team, player_id, player_name, highest_scores,
       RANK() OVER (PARTITION BY team ORDER BY highest_scores DESC) AS score_rank
FROM (
    SELECT 'team_bleedblue' AS team, player_id, player_name, highest_scores FROM team_bleedblue
    UNION ALL
    SELECT 'team_maroon_mavericks' AS team, player_id, player_name, highest_scores FROM team_maroon_mavericks
) AS all_players;

-- 3. Calculate the average highest scores for each role within each team
SELECT team, role, AVG(highest_scores) AS avg_highest_scores
FROM (
    SELECT 'team_bleedblue' AS team, role, highest_scores FROM team_bleedblue
    UNION ALL
    SELECT 'team_maroon_mavericks' AS team, role, highest_scores FROM team_maroon_mavericks
) AS all_players
GROUP BY team, role;

-- 4. Calculate the total batting average for each team
SELECT 'team_bleedblue' AS team, SUM(batting_average) AS total_batting_average
FROM team_bleedblue
UNION ALL
SELECT 'team_maroon_mavericks' AS team, SUM(batting_average) AS total_batting_average
FROM team_maroon_mavericks;

-- Rank players based on their highest scores within each team
SELECT player_id, player_name, highest_scores,
       RANK() OVER (ORDER BY highest_scores DESC) AS score_rank
FROM team_bleedblue
UNION ALL
SELECT player_id, player_name, highest_scores,
       RANK() OVER (ORDER BY highest_scores DESC) AS score_rank
FROM team_maroon_mavericks;

-- Window Functions

-- Calculate the average highest scores for each role within each team
SELECT role, AVG(highest_scores) OVER (PARTITION BY role) AS avg_highest_scores
FROM team_bleedblue
UNION ALL
SELECT role, AVG(highest_scores) OVER (PARTITION BY role) AS avg_highest_scores
FROM team_maroon_mavericks;


SELECT team, player_name, batting_average,
           RANK() OVER (PARTITION BY team ORDER BY batting_average DESC) AS batting_avg_rank
    FROM (
        SELECT 'team_bleedblue' AS team, player_name, batting_average FROM team_bleedblue
        UNION ALL
        SELECT 'team_maroon_mavericks' AS team, player_name, batting_average FROM team_maroon_mavericks
    ) AS all_players;








-- example 2:
WITH ranked_players AS (
    SELECT team, player_name, batting_average,
           RANK() OVER (PARTITION BY team ORDER BY batting_average DESC) AS batting_avg_rank
    FROM (
        SELECT 'team_bleedblue' AS team, player_name, batting_average FROM team_bleedblue
        UNION ALL
        SELECT 'team_maroon_mavericks' AS team, player_name, batting_average FROM team_maroon_mavericks
    ) AS all_players
)
SELECT team, player_name, batting_average
FROM ranked_players
WHERE batting_avg_rank = 2;

-- example 3: Finding the 2nd Highest Batting Average
SELECT player_name, batting_average
FROM (
    SELECT player_name, batting_average,
           ROW_NUMBER() OVER (ORDER BY batting_average DESC) AS row_num
    FROM (
        SELECT player_name, batting_average FROM team_bleedblue
        UNION ALL
        SELECT player_name, batting_average FROM team_maroon_mavericks
    ) AS all_players
) AS ranked_players
WHERE row_num = 2;


------------------------------------- Day - 4 -------------------------------------------------
--Lag
WITH all_players AS (
    SELECT 'team_bleedblue' AS team, player_name, batting_average FROM team_bleedblue
    UNION ALL
    SELECT 'team_maroon_mavericks' AS team, player_name, batting_average FROM team_maroon_mavericks
)
SELECT team, player_name, batting_average,
       LAG(batting_average) OVER (PARTITION BY team ORDER BY batting_average DESC) AS previous_batting_average
FROM all_players;

--Lead
WITH all_players AS (
    SELECT 'team_bleedblue' AS team, player_name, batting_average FROM team_bleedblue
    UNION ALL
    SELECT 'team_maroon_mavericks' AS team, player_name, batting_average FROM team_maroon_mavericks
)
SELECT team, player_name, batting_average,
       LEAD(batting_average) OVER (PARTITION BY team ORDER BY batting_average DESC) AS next_batting_average
FROM all_players;


----- Normalization
----- 1NF
-- 1) Data should be atomic, no comma seperated values.
-- 2) should not contain repeated column groups
-- 3) identify each row uniquely using PK.

----- 2NF
-- 1) should satisfy 1NF
-- 2) move redundant data to seperate table
-- 3) create relationship between these two tables using forign key.

----- 3NF
-- 1) satisfies 1NF and 2NF
-- 2) Does not contains cols that are not fully dependent on PK.


---- fk
CREATE TABLE Team (
    team_id INT PRIMARY KEY,
    team_name VARCHAR(100)
);
CREATE TABLE Player (
    player_id INT PRIMARY KEY,
    player_name VARCHAR(100),
    team_id INT,
    FOREIGN KEY (team_id) REFERENCES Team(team_id)
);
CREATE TABLE PlayerStats (
    player_id INT PRIMARY KEY,
    batting_average DECIMAL(5, 2),
    city VARCHAR(100),
    FOREIGN KEY (player_id) REFERENCES Player(player_id)
);

-- First, insert data into the Team table
INSERT INTO Team (team_id, team_name) VALUES (1, 'team_bleedblue');
INSERT INTO Team (team_id, team_name) VALUES (2, 'team_maroon_mavericks');

-- Now, insert data into the Player table
INSERT INTO Player (player_id, player_name, team_id) VALUES (1, 'Virat Kohli', 1);
INSERT INTO Player (player_id, player_name, team_id) VALUES (2, 'Rohit Sharma', 1);
INSERT INTO Player (player_id, player_name, team_id) VALUES (3, 'Mahendra Dhoni', 2);

-- First, insert data into the PlayerStats table
INSERT INTO PlayerStats (player_id, batting_average, city) VALUES (1, 55.3, 'Delhi');
INSERT INTO PlayerStats (player_id, batting_average, city) VALUES (2, 48.5, 'Mumbai');
INSERT INTO PlayerStats (player_id, batting_average, city) VALUES (3, 50.4, 'Ranchi');


-- This will fail because there is no team_id = 3 in the Team table
INSERT INTO Player (player_id, player_name, team_id) VALUES (4, 'Unknown Player', 3);















--- Stored procedures

-- 1) Normal Stored Procedure
CREATE PROCEDURE spGetAllPlayers
AS
BEGIN
    SELECT * FROM Player;
END;

-- 2) Stored Procedure with single Input Parameters
CREATE PROCEDURE spGetPlayersByTeam
    @TeamID INT
AS
BEGIN
    SELECT player_id, player_name, team_id
    FROM Player
    WHERE team_id = @TeamID;
END;

-- 3)Stored Procedure with Multiple Input Parameters
CREATE PROCEDURE GetPlayersByTeamAndAverage
    @TeamID INT,
    @MinAverage DECIMAL(5, 2)
AS
BEGIN
    SELECT p.player_id, p.player_name, ps.batting_average
    FROM Player p
    JOIN PlayerStats ps ON p.player_id = ps.player_id
    WHERE p.team_id = @TeamID AND ps.batting_average >= @MinAverage;
END;


-- 4) Stored Procedure to Update a Player's Batting Average
CREATE PROCEDURE UpdatePlayerBattingAverage
    @PlayerID INT,
    @NewBattingAverage DECIMAL(5, 2)
AS
BEGIN
    UPDATE PlayerStats
    SET batting_average = @NewBattingAverage
    WHERE player_id = @PlayerID;
END;

EXEC UpdatePlayerBattingAverage @PlayerID = 1, @NewBattingAverage = 60.0;















